/**
 * Guild Cache Manager
 * WORLD BEST in-memory cache for guild data, alerts, trading states
 */

interface GuildCache {
  alerts?: any[];
  tradingState?: boolean;
  lastUpdated: number;
}

const guildCache: Map<string, GuildCache> = new Map();

/**
 * Get guild cache
 */
export function getGuildCache(guildId: string): GuildCache {
  if (!guildCache.has(guildId)) {
    guildCache.set(guildId, { alerts: [], tradingState: false, lastUpdated: Date.now() });
  }
  return guildCache.get(guildId)!;
}

/**
 * Update guild cache
 */
export function updateGuildCache(guildId: string, updates: Partial<GuildCache>): GuildCache {
  const cache = getGuildCache(guildId);
  const newCache = { ...cache, ...updates, lastUpdated: Date.now() };
  guildCache.set(guildId, newCache);
  return newCache;
}

/**
 * Clear guild cache
 */
export async function clearGuildCache(guildId?: string): Promise<number> {
  if (guildId) {
    guildCache.delete(guildId);
    return 1;
  } else {
    const count = guildCache.size;
    guildCache.clear();
    return count;
  }
}