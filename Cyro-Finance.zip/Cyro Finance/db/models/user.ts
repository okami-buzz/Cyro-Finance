import { DataTypes, Model } from "sequelize";
import { sequelize } from "../index";

/**
 * User Model
 * WORLD BEST for Cyro Finance
 * Stores user profile, wallet links, premium status, settings, cooldowns
 */

export class User extends Model {
  declare id: number;
  declare discordId: string;
  declare walletConnected: boolean;
  declare premium: boolean;
  declare settings: object; // { theme, notifications, alerts, etc. }
  declare cooldowns: object; // { commandName: timestamp }
}

User.init(
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
    },
    discordId: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
    },
    walletConnected: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false,
    },
    premium: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false,
    },
    settings: {
      type: DataTypes.JSON,
      allowNull: false,
      defaultValue: {},
    },
    cooldowns: {
      type: DataTypes.JSON,
      allowNull: false,
      defaultValue: {},
    },
  },
  {
    tableName: "users",
    sequelize,
    timestamps: true,
    modelName: "User",
  }
);