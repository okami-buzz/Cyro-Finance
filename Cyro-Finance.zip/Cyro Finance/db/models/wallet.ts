import { DataTypes, Model } from "sequelize";
import { sequelize } from "../index";

/**
 * Wallet Model
 * WORLD BEST for Cyro Finance
 * Stores user wallet data (balances, tokens, NFTs, history)
 */

export class Wallet extends Model {
  declare id: number;
  declare userId: string;
  declare balance: number;
  declare tokens: object;   // { symbol: amount }
  declare nfts: object;     // { nftId: metadata }
  declare history: object[]; // [{ type, symbol, amount, date }]
}

Wallet.init(
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
    },
    userId: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
    },
    balance: {
      type: DataTypes.DOUBLE,
      allowNull: false,
      defaultValue: 0,
    },
    tokens: {
      type: DataTypes.JSON,
      allowNull: false,
      defaultValue: {},
    },
    nfts: {
      type: DataTypes.JSON,
      allowNull: false,
      defaultValue: {},
    },
    history: {
      type: DataTypes.JSON,
      allowNull: false,
      defaultValue: [],
    },
  },
  {
    tableName: "wallets",
    sequelize,
    timestamps: true,
    modelName: "Wallet",
  }
);